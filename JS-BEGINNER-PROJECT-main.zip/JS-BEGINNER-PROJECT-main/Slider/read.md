<h1> Simple Slider to Understand the concept </h1>
